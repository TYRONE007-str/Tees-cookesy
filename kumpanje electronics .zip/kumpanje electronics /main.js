/* ===== MOBILE MENU ===== */

function toggleMenu() {
  document.getElementById("navLinks").classList.toggle("active");
  document.getElementById("menuToggle").classList.toggle("active");
}

/* CLOSE MENU */

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => {
    document.getElementById("navLinks").classList.remove("active");
    document.getElementById("menuToggle").classList.remove("active");
  });
});

/* ===== WHATSAPP FORM ===== */

function sendToWhatsApp(e) {
  
  e.preventDefault();
  
  const name = document.getElementById("name").value.trim();
  const message = document.getElementById("message").value.trim();
  
  if (name === "" || message === "") {
    alert("Please fill in your name and message.");
    return;
  }
  
  const text =
    `Hello Kumpanje Electronics 👋, my name is ${name}.%0A%0A${message}`;
  
  const url =
    `https://wa.me/265991616977?text=${text}`;
  
  window.open(url, "_blank");
}

/* ===== PRODUCT FILTER ===== */

function filterProducts(category, button) {
  
  document.querySelectorAll(".filter-tab").forEach(tab => {
    tab.classList.remove("active");
  });
  
  button.classList.add("active");
  
  document.querySelectorAll(".product-card").forEach(card => {
    
    if (category === "all" || card.dataset.cat === category) {
      card.style.display = "block";
    } else {
      card.style.display = "none";
    }
    
  });
  
}

/* ===== SCROLL REVEAL ===== */

const observer = new IntersectionObserver((entries) => {
  
  entries.forEach(entry => {
    
    if (entry.isIntersecting) {
      entry.target.classList.add("in-view");
    }
    
  });
  
}, {
  threshold: 0.1
});

document.querySelectorAll(".reveal").forEach(el => {
  observer.observe(el);
});